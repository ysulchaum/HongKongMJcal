// Yu Sui Chung 1155177344 3310 asg1
package edu.cuhk.csci3310;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    //private static final int CORRECT_PASSCODE = 123456789; // Set your code
    private StringBuilder mInputCode = new StringBuilder();
    private MediaPlayer mMediaPlayer;
    private int mPassCode;
    private TextView mShowPasscode;
    // Add these variables
    private ImageView mSecretImage;
    private TextView mErrorMessage;

    int[] buttonIds = {
            R.id.button0,
            R.id.button1,
            R.id.button2,
            R.id.button3,
            R.id.button4,
            R.id.button5,
            R.id.button6,
            R.id.button7,
            R.id.button8,
            R.id.button9

    };

    // Verhoeff configuration tables
    private static final int[][] d = {
            {0,1,2,3,4,5,6,7,8,9}, {1,2,3,4,0,6,7,8,9,5},
            {2,3,4,0,1,7,8,9,5,6}, {3,4,0,1,2,8,9,5,6,7},
            {4,0,1,2,3,9,5,6,7,8}, {5,9,8,7,6,0,4,3,2,1},
            {6,5,9,8,7,1,0,4,3,2}, {7,6,5,9,8,2,1,0,4,3},
            {8,7,6,5,9,3,2,1,0,4}, {9,8,7,6,5,4,3,2,1,0}
    };

    private static final int[][] p = {
            {0,1,2,3,4,5,6,7,8,9}, {1,5,7,6,2,8,3,0,9,4},
            {5,8,0,3,7,9,6,1,4,2}, {8,9,1,6,0,4,3,5,2,7},
            {9,4,5,3,1,2,6,8,7,0}, {4,2,8,6,5,7,3,9,0,1},
            {2,7,9,3,8,0,6,4,1,5}, {7,0,4,6,9,1,3,2,5,8}
    };

    private static final int[] inv = {0,4,3,2,1,5,6,7,8,9};

    // Damm algorithm matrix
    private static final int[][] dammMatrix = {
            {0,3,1,7,5,9,8,6,4,2}, {7,0,9,2,1,5,4,8,6,3},
            {4,2,0,6,8,7,1,3,5,9}, {1,7,5,0,9,8,3,4,2,6},
            {6,1,2,3,0,4,5,9,7,8}, {3,6,7,4,2,0,9,5,8,1},
            {5,8,6,9,7,2,0,1,3,4}, {8,9,4,5,3,6,2,0,1,7},
            {9,4,3,8,6,1,7,2,0,5}, {2,5,8,1,4,3,6,7,9,0}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mShowPasscode = findViewById(R.id.passcodeView);
        mSecretImage = findViewById(R.id.hidden_bird);
        mErrorMessage = findViewById(R.id.errorMessage);

        mSecretImage.setVisibility(View.GONE);  // Hide image

        // Initialize media player
        mMediaPlayer = MediaPlayer.create(this, R.raw.ding_louder); // Add sound to res/raw

    }


    private void showToastMessage(String message) {
        Context context = getApplicationContext();
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, message, duration);
        toast.show();
    }
    private void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Alert Dialog Title");
        builder.setMessage("Passcode Incorrect, try again");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle the positive button click
                dialog.dismiss(); // Close the dialog
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Handle the negative button click
                dialog.dismiss(); // Close the dialog
            }
        });

        // Create and show the AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void disableAllButtons() {
        ViewGroup rootLayout = findViewById(android.R.id.content); // This gets the root view
        disableButtons(rootLayout);
    }

    private void disableButtons(ViewGroup viewGroup) {
        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            View child = viewGroup.getChildAt(i);
            if (child instanceof Button) {
                child.setEnabled(false); // Disable the button
            } else if (child instanceof ViewGroup) {
                disableButtons((ViewGroup) child); // Recursive call for nested ViewGroups
            }
        }
    }

    private int computeVerhoeffCheckDigit(String data) {
        int c = 0;
        for (int i = 0; i < data.length(); i++) {
            char ch = data.charAt(data.length() - 1 - i); // Process right-to-left
            int digit = Character.getNumericValue(ch);
            c = d[c][p[(i + 1) % 8][digit]];
        }
        return inv[c];
    }

    private int computeDammCheckDigit(String data) {
        int interim = 0;
        for (int i = 0; i < data.length(); i++) {
            int digit = Character.getNumericValue(data.charAt(i));
            interim = dammMatrix[interim][digit];
        }

        // Find column with 0 in the final interim row
        for (int c = 0; c < 10; c++) {
            if (dammMatrix[interim][c] == 0) return c;
        }
        return -1; // Should never happen with valid matrix
    }



    private boolean checkPasscode() {
        String input = mInputCode.toString();

        // Must have 2+ digits
        if (input.length() < 2) return false;

        // Split input
        String data = input.substring(0, input.length() - 1);
        int checkDigit = Character.getNumericValue(input.charAt(input.length() - 1));

        // Calculate both check digits
        int verhoeff = computeVerhoeffCheckDigit(data);
        int damm = computeDammCheckDigit(data);

        // Accept either valid check digit
        return (checkDigit == verhoeff) || (checkDigit == damm);
    }

    public void colorCue(){
        String input = mInputCode.toString();
        if (input.length() >= 2) {
            // Get Verhoeff's and Damm's check digits
            String data = input.substring(0, input.length() - 1);
            int verhoeff = computeVerhoeffCheckDigit(data);
            int damm = computeDammCheckDigit(data);

            // Reset button colors
            recoverColor(103,80,164,255);

            // Set colors based on check digits
            if (verhoeff == damm) {
                Button b = findViewById(buttonIds[verhoeff]);
                b.setBackgroundColor(Color.rgb(255, 165, 0)); // Bright Orange
            } else {
                Button verhoeffButton = findViewById(buttonIds[verhoeff]);
                verhoeffButton.setBackgroundColor(Color.YELLOW); // Bright Yellow

                Button dammButton = findViewById(buttonIds[damm]);
                dammButton.setBackgroundColor(Color.RED); // Bright Red
            }
        }
    }

    public void updatePasscode(View view) {
        Button button = (Button) view;
        mInputCode.append(button.getText());
        button.setAlpha(0.8f);
        colorCue();
        updateDisplay();

    }

    public void undoPasscode(View view) {
        if (mInputCode.length() > 0) {
            mInputCode.deleteCharAt(mInputCode.length() - 1);
            recoverButtons();
            recoverColor(103,80,164,255);
            updateDisplay();
        }
    }

    public void onUnlockButtonClick(View view) {
        recoverButtons();
        if (checkPasscode()) {
            handleCorrectCode();
            recoverColor(227,223,227,255);
            showToastMessage("Passcode Accepted");
        } else {
            showAlertDialog();
            recoverColor(103,80,164,255);
        }
        resetInput();
    }


    private void  recoverColor(int r, int g, int b, int a){
        for (int otherId : buttonIds) {
            // Check if the button is not the one clicked
            Button Button = findViewById(otherId);
            Button.setBackgroundColor(Color.argb(a, r, g, b));
        }
    }
    private  void recoverButtons(){
        for (int otherId : buttonIds) {
            // Check if the button is not the one clicked
            Button Button = findViewById(otherId);
            Button.setAlpha(1f);
        }
    }
    private void handleCorrectCode() {
        // Show hidden image
        mSecretImage.setVisibility(View.VISIBLE);
        mErrorMessage.setVisibility(View.GONE);
        // Play success sound
        playSound(R.raw.ding_louder);
        disableAllButtons();
    }


    private void updateDisplay() {
        mShowPasscode.setText("•".repeat(mInputCode.length()));
    }

    private void resetInput() {
        mInputCode.setLength(0);
        updateDisplay();
    }

    private void playSound(int soundRes) {
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
        }
        mMediaPlayer = MediaPlayer.create(this, soundRes);
        mMediaPlayer.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
        }
    }
}

// some of the code power by chatgpt